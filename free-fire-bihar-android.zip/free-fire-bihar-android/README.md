# Free Fire Bihar – Android packaging

The game is a single offline file (`www/index.html`, about 25 KB) with no external
assets, so the finished APK is expected to land around 3–6 MB, well under the
20–30 MB target. Nothing needs to be added to reach that range.

## Requirements
Node 18+, JDK 17, Android Studio (or the Android SDK command-line tools).

## Build steps
```bash
npm install
npx cap add android          # creates the android/ folder once
npm run icons                # makes all launcher icons from assets/
npm run sync                 # copies www/ into the app
```

### Keep the app small (edit android/app/build.gradle)
In `android { buildTypes { release { ... } } }` set:
```gradle
minifyEnabled true
shrinkResources true
proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
```
and inside `android { }` add:
```gradle
splits { abi { enable true; reset(); include 'armeabi-v7a','arm64-v8a'; universalApk false } }
```
(The game has no native code, so ABI splits are optional; Play Store AAB handles this for you.)

### Landscape/portrait, fullscreen
The game adapts to both. To lock landscape, add
`android:screenOrientation="sensorLandscape"` to the `<activity>` in
`android/app/src/main/AndroidManifest.xml`.

### Test build (debug APK, no signing needed)
```bash
npm run debug
# -> android/app/build/outputs/apk/debug/app-debug.apk
```

### Release build
```bash
keytool -genkey -v -keystore ffb-release.jks -alias ffb -keyalg RSA -keysize 2048 -validity 10000
```
Add the keystore to `android/app/build.gradle` (`signingConfigs`) or sign in Android Studio
via Build > Generate Signed Bundle / APK, then:
```bash
npm run apk     # signed APK for sideloading
npm run aab     # .aab for Google Play (smallest download)
```

## Notes
- The best score is saved in WebView localStorage and stays on the device.
- "Free Fire" is a registered trademark of Garena. Using it for a public Play Store
  listing can lead to a takedown, so consider a distinct name before publishing.
